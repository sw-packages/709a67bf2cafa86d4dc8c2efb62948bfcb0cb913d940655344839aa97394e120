/*-------------------------------------------------------------------------
 *
 * unicode_version.h
 *	  Unicode version used by Postgres.
 *
 * Portions Copyright (c) 1996-2024, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 *
 * src/include/common/unicode_version.h
 *
 *-------------------------------------------------------------------------
 */

#define PG_UNICODE_VERSION		"15.1"
